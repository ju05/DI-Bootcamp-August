#CONDITIONALS

#SYNTAX
#if <condition>:
#(indented block) <action>

# if 5 < 3:
#     print('Hello there!')

# user_num = int(input('Guess a number'))
# secret_num = 18

# if user_num == secret_num:
#     print('Congrats, you won!')

# elif user_num == 7:
#     print('Thats my lucky number!')

# elif user_num < 1: 
#     print('Don\'t enter negative numbers')

# else:
#     print('Wrong number, try again')

#Exercise in class
# user_name = input('Please enter your name:')

# if len(user_name) <= 5:
#     print('You have a short name')
# else:
#     print('You have a long name')

my_hobbies = "sport, code, food, icecreams, netflix"

if 'yoga' in my_hobbies or 'soccer' in my_hobbies:
    print('Let\'s have medidation!')